/**
 * Created by bootcamp on 9/23/15.
 */
var master_url="http://localhost:8080/";